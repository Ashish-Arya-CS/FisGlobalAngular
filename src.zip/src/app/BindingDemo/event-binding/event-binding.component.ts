import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-event-binding',
  templateUrl: './event-binding.component.html',
  styleUrls: ['./event-binding.component.css']
})
export class EventBindingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  textMessage: string = ""
  msg: string = ""
  info: string = ""
  onChangeEvent(event?: any) {
    console.log(event.target.value);
    this.textMessage = event.target.value;

  }

  AddtoCart2() {
    this.msg = "Product Added in cart";

  }
  AddtoCart(event?: MouseEvent) {
    this.msg = event ? (event.target as HTMLElement).innerHTML + " Added in Cart" : "";
  }
  getInputInfo(myInputinfo: any) {
    console.log(myInputinfo.value)
    this.info = myInputinfo.value

  }


}
