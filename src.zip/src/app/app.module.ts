import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './MyFirstAngularWebsite/header/header.component';
import { TopnavComponent } from './MyFirstAngularWebsite/topnav/topnav.component';
import { TxtBlockLeftComponent } from './MyFirstAngularWebsite/txt-block-left/txt-block-left.component';
import { TxtBlockRightComponent } from './MyFirstAngularWebsite/txt-block-right/txt-block-right.component';
import { OneWayBindingComponent } from './BindingDemo/one-way-binding/one-way-binding.component';
import { TwoWayBindingComponent } from './BindingDemo/two-way-binding/two-way-binding.component';
import { EventBindingComponent } from './BindingDemo/event-binding/event-binding.component';
import { NgIfDemoComponent } from './DirectivesDemo/ng-if-demo/ng-if-demo.component';
import { NgSwitchDemoComponent } from './DirectivesDemo/ng-switch-demo/ng-switch-demo.component';
import { NgForDemoComponent } from './DirectivesDemo/ng-for-demo/ng-for-demo.component';
import { AngularPipeDemoComponent } from './PipeDemo/angular-pipe-demo/angular-pipe-demo.component';
import { reverseStrPipe } from './PipeDemo/custom-pipes.pipe';
import { UsesOfCustomPipeComponent } from './PipeDemo/uses-of-custom-pipe/uses-of-custom-pipe.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    TopnavComponent,
    TxtBlockLeftComponent,
    TxtBlockRightComponent,
    OneWayBindingComponent,
    TwoWayBindingComponent,
    EventBindingComponent,
    NgIfDemoComponent,
    NgSwitchDemoComponent,
    NgForDemoComponent,
    AngularPipeDemoComponent,
    reverseStrPipe,
    UsesOfCustomPipeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
