import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './MyFirstAngularWebsite/header/header.component';
import { TopnavComponent } from './MyFirstAngularWebsite/topnav/topnav.component';
import { TxtBlockLeftComponent } from './MyFirstAngularWebsite/txt-block-left/txt-block-left.component';
import { TxtBlockRightComponent } from './MyFirstAngularWebsite/txt-block-right/txt-block-right.component';
import { OneWayBindingComponent } from './BindingDemo/one-way-binding/one-way-binding.component';
import { TwoWayBindingComponent } from './BindingDemo/two-way-binding/two-way-binding.component';
import { EventBindingComponent } from './BindingDemo/event-binding/event-binding.component';
import { NgIfDemoComponent } from './DirectivesDemo/ng-if-demo/ng-if-demo.component';
import { NgSwitchDemoComponent } from './DirectivesDemo/ng-switch-demo/ng-switch-demo.component';
import { NgForDemoComponent } from './DirectivesDemo/ng-for-demo/ng-for-demo.component';
import { AngularPipeDemoComponent } from './PipeDemo/angular-pipe-demo/angular-pipe-demo.component';
import { reverseStrPipe } from './PipeDemo/custom-pipes.pipe';
import { UsesOfCustomPipeComponent } from './PipeDemo/uses-of-custom-pipe/uses-of-custom-pipe.component';
import { BootStrap5DemoComponent } from './BootstrapDemo/boot-strap5-demo/boot-strap5-demo.component';
import { NgxBootstrapDatepickerComponent } from './BootstrapDemo/ngx-bootstrap-datepicker/ngx-bootstrap-datepicker.component';
import { Route, Router, RouterModule, Routes } from '@angular/router';
import { ProductComponent } from './InputAndOutputDecoratorDemo/InputDecoratorDemo/product/product.component';
import { ProductlistComponent } from './InputAndOutputDecoratorDemo/InputDecoratorDemo/productlist/productlist.component';
import { ChildComponent } from './InputAndOutputDecoratorDemo/OutputDecoratorDemo/child/child.component';
import { ParentComponent } from './InputAndOutputDecoratorDemo/OutputDecoratorDemo/parent/parent.component';
import { ConsumeUtilityServiceComponent } from './ServiceDemo/consume-utility-service/consume-utility-service.component';

const appRoutes : Routes=[
{path:'Header',component:HeaderComponent},
{path:'OneWayBinding',component:OneWayBindingComponent},
{path:'TwoWayBinding',component:TwoWayBindingComponent},
{path:'EventBinding',component:EventBindingComponent},
{path:'NgIfDemo',component:NgIfDemoComponent},
{path:'NgSwitchDemo',component:NgSwitchDemoComponent},
{path:'NgForDemo',component:NgForDemoComponent},
{path:'AngularPipeDemo',component:AngularPipeDemoComponent},
{path:'UsesOfCustomPipe',component:UsesOfCustomPipeComponent},
{path:'BootStrap5Demo',component:BootStrap5DemoComponent},
{path:'Product',component:ProductComponent},
{path:'Parent',component:ParentComponent},
{path:'ConsumeUtilityService',component:ConsumeUtilityServiceComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    TopnavComponent,
    TxtBlockLeftComponent,
    TxtBlockRightComponent,
    OneWayBindingComponent,
    TwoWayBindingComponent,
    EventBindingComponent,
    NgIfDemoComponent,
    NgSwitchDemoComponent,
    NgForDemoComponent,
    AngularPipeDemoComponent,
    reverseStrPipe,
    UsesOfCustomPipeComponent,
    BootStrap5DemoComponent,
    NgxBootstrapDatepickerComponent,
    ProductComponent,
    ProductlistComponent,
    ChildComponent,
    ParentComponent,
    ConsumeUtilityServiceComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
