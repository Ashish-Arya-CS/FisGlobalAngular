import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BootStrap5DemoComponent } from './boot-strap5-demo.component';

describe('BootStrap5DemoComponent', () => {
  let component: BootStrap5DemoComponent;
  let fixture: ComponentFixture<BootStrap5DemoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BootStrap5DemoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BootStrap5DemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
