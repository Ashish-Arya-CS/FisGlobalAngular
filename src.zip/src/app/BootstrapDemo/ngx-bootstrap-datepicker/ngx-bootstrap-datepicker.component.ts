import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ngx-bootstrap-datepicker',
  templateUrl: './ngx-bootstrap-datepicker.component.html',
  styleUrls: ['./ngx-bootstrap-datepicker.component.css']
})
export class NgxBootstrapDatepickerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
