import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-txt-block-right',
  templateUrl: './txt-block-right.component.html',
  styleUrls: ['./txt-block-right.component.css']
})
export class TxtBlockRightComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
