import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-txt-block-left',
  templateUrl: './txt-block-left.component.html',
  styleUrls: ['./txt-block-left.component.css']
})
export class TxtBlockLeftComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
