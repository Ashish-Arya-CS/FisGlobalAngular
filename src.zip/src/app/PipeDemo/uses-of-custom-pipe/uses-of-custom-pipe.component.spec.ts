import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UsesOfCustomPipeComponent } from './uses-of-custom-pipe.component';

describe('UsesOfCustomPipeComponent', () => {
  let component: UsesOfCustomPipeComponent;
  let fixture: ComponentFixture<UsesOfCustomPipeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UsesOfCustomPipeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UsesOfCustomPipeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
