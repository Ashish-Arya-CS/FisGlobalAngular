import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ng-for-demo',
  templateUrl: './ng-for-demo.component.html',
  styleUrls: ['./ng-for-demo.component.css']
})
export class NgForDemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  products=[
    {id:'pro1001',proimg:"",name:"Laptop",price:35000},
    {id:'pro1002',proimg:"",name:"Mobile",price:15000},
    {id:'pro1003',proimg:"",name:"Pen Drive",price:1500},
    {id:'pro1004',proimg:"",name:"Led",price:12000}
  ]

  myobject=[];

}
