import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-for-of-demo',
  templateUrl: './for-of-demo.component.html',
  styleUrls: ['./for-of-demo.component.css']
})
export class ForOfDemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  products=[
    {id:'pro1001', proimg:"", name:"Laptop",price:1500},
    {id:'pro1002', proimg:"", name:"Mobile",price:2500},
    {id:'pro1003', proimg:"", name:"Desktop",price:3500},
    {id:'pro1004', proimg:"", name:"TV",price:4500}
  ]
  myobject = []

}
