import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForOfDemoComponent } from './for-of-demo.component';

describe('ForOfDemoComponent', () => {
  let component: ForOfDemoComponent;
  let fixture: ComponentFixture<ForOfDemoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForOfDemoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ForOfDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
