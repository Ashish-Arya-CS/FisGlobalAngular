import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomPipeUsesComponent } from './custom-pipe-uses.component';

describe('CustomPipeUsesComponent', () => {
  let component: CustomPipeUsesComponent;
  let fixture: ComponentFixture<CustomPipeUsesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomPipeUsesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomPipeUsesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
