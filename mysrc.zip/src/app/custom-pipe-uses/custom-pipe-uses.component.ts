import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-pipe-uses',
  templateUrl: './custom-pipe-uses.component.html',
  styleUrls: ['./custom-pipe-uses.component.css']
})
export class CustomPipeUsesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  Name: string = "ABHISHEK SHARMA"
  today: number = Date.now();
  msg: string = "This is demo text"
  products = [
    { proimg: '', name: 'Laptop', id: 'pro01', price: 15000 },
    { proimg: '', name: 'Mobile', id: 'pro02', price: 8000 },
    { proimg: '', name: 'Led', id: 'pro03', price: 12000 },
    { proimg: '', name: 'Pen Drive', id: 'pro04', price: 20000 }
  ]
}
