import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-one-way-binding',
  templateUrl: './one-way-binding.component.html',
  styleUrls: ['./one-way-binding.component.css']
})
export class OneWayBindingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  dynamicName : string = "Ashish";
  myMethod(){
    return "This is data binding in Angular by "+this.dynamicName
  }
  appStatus : boolean = true;
  status1 : string = "Online";
  status2 : string = "Offline";

  enable : boolean = true;
  msg : string = "";
  onAddCart(){
    this.msg="Product add to Cart"
  }
  onInputClick(event : any){
    console.log(event)
  }
  myStyle = {
    'background' : 'red',
    'border': '10px solid green'
  }
  mltClasses={
    class1: true,
    class2 : true,
    class3 : false
  }

}