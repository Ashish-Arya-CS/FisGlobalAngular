import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-event-binding',
  templateUrl: './event-binding.component.html',
  styleUrls: ['./event-binding.component.css']
})
export class EventBindingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  textMessage : string="";
  msg : string="";
  info:string="";
  
  AddtoCart2(){
    this.msg="Product Added to cart";
  }
  AddtoCart(event?:MouseEvent){
    this.msg = event?(event.target as HTMLElement).innerHTML + "Added in Cart":"Some error";
  }
  onChangeEvent(event?:any){
    console.log(event.target.value);
    this.textMessage = event.target.value;
  }
  getInputInfo(myInputinfo:any){
    console.log(myInputinfo);
    this.info = myInputinfo.value;
  }
}
