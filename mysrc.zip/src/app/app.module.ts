import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './MyFirstAngularWebsite/header/header.component';
import { TopnavComponent } from './MyFirstAngularWebsite/topnav/topnav.component';
import { TxtBlockLeftComponent } from './MyFirstAngularWebsite/txt-block-left/txt-block-left.component';
import { TxtBlockRightComponent } from './MyFirstAngularWebsite/txt-block-right/txt-block-right.component';
import { OneWayBindingComponent } from './BindingDemo/one-way-binding/one-way-binding.component';
import { TwoWayBindingComponent } from './BindingDemo/two-way-binding/two-way-binding.component';
import { EventBindingComponent } from './BindingDemo/event-binding/event-binding.component';
import { NgIfDemoComponent } from './DirectivesDemo/ng-if-demo/ng-if-demo.component';
import { SwitchDemoComponent } from './DirectivesDemo/switch-demo/switch-demo.component';
import { ForOfDemoComponent } from './DirectivesDemo/for-of-demo/for-of-demo.component';
import { PipeDemoComponent } from './pipe-demo/pipe-demo.component';
import { CustomPipesPipe } from './custom-pipes.pipe';
import { CustomPipeUsesComponent } from './custom-pipe-uses/custom-pipe-uses.component';
import { RouterModule, Routes } from '@angular/router';

const appRoutes : Routes=[
  {path:'OneWayBinding', component:OneWayBindingComponent},
  {path:'TwoWayBinding', component:TwoWayBindingComponent},
  {path:'EventBinding', component:EventBindingComponent},
  {path:'NgIfDemo', component:NgIfDemoComponent},
  {path:'SwitchDemo', component:SwitchDemoComponent},
  {path:'ForOfDemo', component:ForOfDemoComponent},
  {path:'PipeDemo', component:PipeDemoComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    TopnavComponent,
    TxtBlockLeftComponent,
    TxtBlockRightComponent,
    OneWayBindingComponent,
    TwoWayBindingComponent,
    EventBindingComponent,
    NgIfDemoComponent,
    SwitchDemoComponent,
    ForOfDemoComponent,
    PipeDemoComponent,
    CustomPipesPipe,
    CustomPipeUsesComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
