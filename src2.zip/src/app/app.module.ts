import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule, ReactiveFormsModule} from '@angular/forms'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PushSpliceWithForDemoComponent } from './AngularConcepts/push-splice-with-for-demo/push-splice-with-for-demo.component';
import { TemplateDrivenFormDemoComponent } from './AngularFormDemo/template-driven-form-demo/template-driven-form-demo.component';
import { ReactiveFormDemoComponent } from './AngularFormDemo/reactive-form-demo/reactive-form-demo.component';
import { FormBuilderDemoComponent } from './AngularFormDemo/form-builder-demo/form-builder-demo.component';
import { AddUserComponent } from './CrudUserWithWebApi/add-user/add-user.component';
import { UpdateUserComponent } from './CrudUserWithWebApi/update-user/update-user.component';
import { DeleteUserComponent } from './CrudUserWithWebApi/delete-user/delete-user.component';
import { DetailsUserComponent } from './CrudUserWithWebApi/details-user/details-user.component';
import {Routes, RouterModule} from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { UsersListComponent } from './CrudUserWithWebApi/users-list/users-list.component';
const  appRoutes: Routes=[
  {path:'AddUser',component:AddUserComponent},
  {path:'ListUsers',component:UsersListComponent},
  {path:'UpdateUser',component:UpdateUserComponent},
  {path:'DeleteUser',component:DeleteUserComponent},
  {path:'DetailsUser',component:DetailsUserComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    PushSpliceWithForDemoComponent,
    TemplateDrivenFormDemoComponent,
    ReactiveFormDemoComponent,
    FormBuilderDemoComponent,
    AddUserComponent,
    UpdateUserComponent,
    DeleteUserComponent,
    DetailsUserComponent,
    UsersListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
